const express = require("express");
const fs = require("fs");
const app = express();
const port = 3000;

const dataFile = "mission.json";

app.use(express.urlencoded({ extended: true }));

// Sprawdza czy misja była już otwarta
function isMissionOpened() {
  if (!fs.existsSync(dataFile)) return false;
  const data = JSON.parse(fs.readFileSync(dataFile));
  return data.opened;
}

// Oznacza misję jako otwartą
function openMission() {
  fs.writeFileSync(dataFile, JSON.stringify({ opened: true }));
}

// Strona startowa
app.get("/", (req, res) => {
  if (isMissionOpened()) return res.send(destroyedPage());
  res.send(startPage());
});

// Obsługa przycisków
app.post("/action", (req, res) => {
  const { step } = req.body;

  if (isMissionOpened()) return res.send(destroyedPage());

  if (step === "start") return res.send(missionStepsPage());
  else if (step === "accept") {
    openMission();
    return res.send(finalPage());
  } else if (step === "decline") {
    openMission();
    return res.send(destroyedPage());
  }

  res.redirect("/");
});

// ----- STRONY HTML -----

function startPage() {
  return `
  <!DOCTYPE html>
  <html>
  <head>
    <title>SECURE ACCESS</title>
    <style>
      body { background: black; color: #00ff00; font-family: monospace; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; text-align: center; }
      .box { max-width: 700px; }
      h1 { font-size: 28px; }
      p { font-size: 18px; margin: 15px 0; }
      button { margin: 10px; padding: 15px 35px; font-size: 18px; background: black; color: #00ff00; border: 2px solid #00ff00; cursor: pointer; }
      button:hover { background: #00ff00; color: black; }
      .blink { animation: blink 1s infinite; }
      @keyframes blink { 50% { opacity: 0; } }
    </style>
  </head>
  <body>
    <div class="box">
      <h1>Dobry wieczór, agentko.</h1>
      <p>Zostałaś wytypowana do niezwykle trudnej i ściśle tajnej misji.</p>
      <form method="POST" action="/action">
        <button name="step" value="start">Więcej informacji.</button>
        <button name="step" value="decline">Odmowa.</button>
      </form>
      <p class="blink">_</p>
    </div>
  </body>
  </html>
  `;
}

function missionStepsPage() {
  return `
  <!DOCTYPE html>
  <html>
  <head>
    <title>ETAPY MISJI</title>
    <style>
      body { background: black; color: #00ff00; font-family: monospace; text-align: center; }
      .container { max-width: 800px; margin: 50px auto; }
      h1 { font-size: 32px; margin-bottom: 20px; }
      p { font-size: 18px; margin: 15px 0; }
      button { margin-top: 25px; padding: 15px 40px; font-size: 18px; background: black; color: #00ff00; border: 2px solid #00ff00; cursor: pointer; }
      button:hover { background: #00ff00; color: black; }
      .blink { animation: blink 1s infinite; }
      @keyframes blink { 50% { opacity: 0; } }
    </style>
  </head>
  <body>
    <div class="container">
      <h1>Przebieg misji:</h1>
      <p>> Etap 1: Przeszukiwanie wielu miejsc w celu znalezienia cennych przedmiotów, które mogą zasilić ekwipunek oraz urozmaicić stroje naszych agentów. PS. ten etap nie ma ograniczenia czasowego, a przydzielony do Pani współagent będzie musiał to szanować i chodzić za Panią zadowolony (choćby miał udawać)</p>
      <p>> Etap 2: Zbadanie wpływów amerykańskiej propagandy w pewnej popularnej sieci restauracji.</p>
      <p>> Etap 3: Udanie się w trybie incognito jako klient pewnego podejrzanego biznesu i analiza składu sprzedawanych tam zielony napoji trujących mieszkańców Szczecina.</p>
      <form method="POST" action="/action">
        <button name="step" value="accept">Akceptuję misję.</button>
        <button name="step" value="decline">Odmowa.</button>
      </form>
      <p class="blink">_</p>
    </div>
  </body>
  </html>
  `;
}

function finalPage() {
  return `
  <!DOCTYPE html>
  <html>
  <head>
    <title>MISJA AKCEPTOWANA</title>
    <style>
      body { background: black; color: #00ff00; font-family: monospace; text-align: center; height: 100vh; display: flex; justify-content: center; align-items: center; }
      .box { max-width: 700px; }
      h1 { font-size: 32px; margin-bottom: 20px; }
      p { font-size: 20px; margin: 10px 0; }
    </style>
  </head>
  <body>
    <div class="box">
      <h1>Misja zaakceptowana.</h1>
      <p>Proszę być gotowym w dniu 27.02 godz. 13:00 przed miejscem zamieszaknia.</p>
      <p>Ktoś będzie na Panią czekał.</p>
      <p>It's a date.</p>
    </div>
  </body>
  </html>
  `;
}

function destroyedPage() {
  return `
  <!DOCTYPE html>
  <html>
  <head>
    <title>ACCESS DENIED</title>
    <style>
      body { background: black; color: red; font-family: monospace; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; text-align: center; }
      h1 { font-size: 40px; }
      .glitch { animation: glitch 0.3s infinite; }
      @keyframes glitch { 50% { opacity: 0.2; } }
    </style>
  </head>
  <body>
    <div>
      <h1 class="glitch">AKTA ZNISZCZONE.</h1>
      <p>> Ten link został już aktywowany.</p>
      <p>> Dokumenty uległy samozniszczeniu.</p>
      <p>> Operacja została zamknięta.</p>
    </div>
  </body>
  </html>
  `;
}

// Uruchomienie serwera
app.listen(port, () => {
  console.log("Serwer działa na http://localhost:" + port);
});